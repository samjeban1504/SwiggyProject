import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { deliveryBoyAPI } from '../services/api';
import { BiArrowBack, BiTrash, BiCycling } from 'react-icons/bi';

const AdminDeliveryBoys = () => {
  const navigate = useNavigate();
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const admin = localStorage.getItem('adminUser');
    if (!admin) {
      navigate('/admin/login');
      return;
    }
    fetchDeliveryBoys();
  }, [navigate]);

  const fetchDeliveryBoys = async () => {
    try {
      setLoading(true);
      const res = await deliveryBoyAPI.getAll();
      setDeliveryBoys(res.data);
    } catch (err) {
      setError('Failed to load delivery boys');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteDeliveryBoy = async (id) => {
    if (window.confirm('Are you sure you want to delete this delivery partner?')) {
      try {
        // Note: Implement delete endpoint in backend if needed
        setDeliveryBoys(deliveryBoys.filter(d => d.id !== id));
      } catch (err) {
        setError('Failed to delete delivery boy');
      }
    }
  };

  const getStatusBadge = (available) => {
    return available ? 'success' : 'secondary';
  };

  return (
    <div className="container-fluid py-5" style={{ backgroundColor: '#0f1224' }}>
      <div className="mb-5">
        <button
          className="btn btn-outline-secondary mb-3"
          onClick={() => navigate('/admin/dashboard')}
          style={{ borderRadius: '24px', borderWidth: '1.5px' }}
        >
          <BiArrowBack className="me-2" />
          Back to Dashboard
        </button>
        <h2 className="fw-bold" style={{ color: '#ff6a00' }}>
          <BiCycling className="me-2" style={{ color: '#ff6a00' }} />
          Manage Delivery Partners
        </h2>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="glass-card p-4" style={{ background: 'rgba(20, 18, 39, 0.95)' }}>
        {loading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-warning" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : deliveryBoys.length === 0 ? (
          <div className="text-center py-5 text-muted">
            <p style={{ color: '#ff6a00' }}>No delivery partners found</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-borderless align-middle">
              <thead style={{ backgroundColor: 'rgba(255, 106, 0, 0.12)', borderBottom: '2px solid rgba(255, 106, 0, 0.24)' }}>
                <tr>
                  <th className="text-muted">ID</th>
                  <th className="text-muted">Name</th>
                  <th className="text-muted">Phone</th>
                  <th className="text-muted">Email</th>
                  <th className="text-muted">Status</th>
                  <th className="text-muted">Rating</th>
                  <th className="text-muted">Actions</th>
                </tr>
              </thead>
              <tbody>
                {deliveryBoys.map((boy) => (
                  <tr key={boy.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                    <td className="fw-bold" style={{ color: '#ff6a00' }}>{boy.id}</td>
                    <td className="fw-bold" style={{ color: '#ff6a00' }}>{boy.name}</td>
                    <td style={{ color: '#ffb27a' }}>{boy.phone}</td>
                    <td className="text-muted small">{boy.email || '-'}</td>
                    <td>
                      <span className={`badge bg-${getStatusBadge(boy.available)}`}>
                        {boy.available ? 'Available' : 'Busy'}
                      </span>
                    </td>
                    <td>
                      <span className="badge bg-warning text-dark">
                        ⭐ {boy.rating || '0'}
                      </span>
                    </td>
                    <td>
                      <button
                        className="btn btn-sm"
                        style={{ backgroundColor: 'rgba(255, 106, 0, 0.12)', color: '#ff6a00', border: '1px solid rgba(255, 106, 0, 0.25)', borderRadius: '10px' }}
                        onClick={() => handleDeleteDeliveryBoy(boy.id)}
                      >
                        <BiTrash size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDeliveryBoys;
