import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { orderAPI } from '../services/api';
import { BiArrowBack, BiBox } from 'react-icons/bi';

const AdminOrders = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const admin = localStorage.getItem('adminUser');
    if (!admin) {
      navigate('/admin/login');
      return;
    }
    fetchOrders();
  }, [navigate]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const res = await orderAPI.getAll();
      setOrders(res.data);
    } catch (err) {
      setError('Failed to load orders');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      'PENDING': 'warning',
      'CONFIRMED': 'info',
      'PICKED': 'primary',
      'DELIVERED': 'success',
      'CANCELLED': 'danger'
    };
    return statusMap[status] || 'secondary';
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return '-';
    return new Date(timestamp).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="container-fluid py-4">
      <div className="mb-4">
        <button
          className="btn btn-outline-secondary mb-3"
          onClick={() => navigate('/admin/dashboard')}
        >
          <BiArrowBack className="me-2" />
          Back to Dashboard
        </button>
        <h2 className="fw-bold">
          <BiBox className="me-2" style={{ color: '#fd7e14' }} />
          Manage Orders
        </h2>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="glass-card p-4">
        {loading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-warning" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-5 text-muted">
            <p>No orders found</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover">
              <thead style={{ backgroundColor: 'rgba(253, 126, 20, 0.15)', borderBottom: '2px solid rgba(253, 126, 20, 0.3)' }}>
                <tr>
                  <th style={{ color: '#fd7e14' }}>Order ID</th>
                  <th style={{ color: '#fd7e14' }}>Customer</th>
                  <th style={{ color: '#fd7e14' }}>Restaurant</th>
                  <th style={{ color: '#fd7e14' }}>Status</th>
                  <th style={{ color: '#fd7e14' }}>Total Price</th>
                  <th style={{ color: '#fd7e14' }}>Order Date</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} style={{ borderBottom: '1px solid rgba(253, 126, 20, 0.1)' }}>
                    <td className="fw-bold" style={{ color: '#fd7e14' }}>{order.id}</td>
                    <td>{order.userId || '-'}</td>
                    <td>{order.restaurantId || '-'}</td>
                    <td>
                      <span className={`badge bg-${getStatusBadge(order.status)}`}>
                        {order.status}
                      </span>
                    </td>
                    <td>₹{order.totalPrice?.toFixed(2) || '0.00'}</td>
                    <td className="small text-muted">{formatDate(order.orderDate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminOrders;
